from starlette.middleware.gzip import GZipMiddleware as GZipMiddleware  # noqa
